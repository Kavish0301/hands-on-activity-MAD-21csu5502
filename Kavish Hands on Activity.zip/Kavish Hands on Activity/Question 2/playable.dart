// playable.dart

// Define interface Playable
abstract class Playable {
  void play();
}
